package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App 
{
	public static void main( String[] args ) throws InterruptedException
    {
    	//register the webdriver =>browser vendor 
        WebDriverManager.chromedriver().setup();
        //creating an object to the object
        WebDriver wd=new ChromeDriver();
        //maximize the browser
        wd.manage().window().maximize();
        
        //go to browser and open this url 
        wd.get("https://bstackdemo.com/");
      //supply any data
        //close browser
        wd.findElement(By.cssSelector("a#offers[href='/offers']"));
        
        wd.findElement(By.cssSelector("a.Navbar_link_3Blki[href='orders']"));
        
        wd.findElement(By.cssSelector("a[class^='Navabr_logo_']"));
        Thread.sleep(2000);
        wd.close();
    }
}
