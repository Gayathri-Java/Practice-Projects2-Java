package Project8;

public class Cat {
	 
    String name; 
    
    int age; 
    String color; 
    public Cat(String name,  int age, String color) 
    { 
        this.name = name; 
        this.age = age; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return name; 
    } 
    public int getAge() 
    { 
        return age; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi my name is "+ this.getName()+ " ,"+ this.getAge()+ ", and "+ this.getColor() + "."); 
    } 
    public static void main(String[] args) 
    { 
        Cat scott = new Cat("Scott", 5, "black"); 
        System.out.println(scott.toString()); 
    } 
}

