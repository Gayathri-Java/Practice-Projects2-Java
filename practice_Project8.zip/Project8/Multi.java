package Project8;

public class Multi {
	 public int multi(int x, int y) 
	    { 
	        return (x * y); 
	    } 
	    public int multi(int x, int y, int z) 
	    { 
	        return (x * y * z); 
	    } 
	    public double multi(double x, double y) 
	    { 
	        return (x * y); 
	    } 
	    public static void main(String args[]) 
	    { 
	        Multi s = new Multi(); 
	        System.out.println(s.multi(15, 10)); 
	        System.out.println(s.multi(10, 5, 10)); 
	        System.out.println(s.multi(1.5, 10.5)); 
	    } 
	}

