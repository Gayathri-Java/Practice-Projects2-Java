package Project2;


	class WaitSleep  
	{   
	  
	    //create an instance of the Object   
	    private static Object obj = new Object();   
	  
	    //main() method starts with handling InterruptedException  
	    public static void main(String[] args)throws InterruptedException   
	    {   
	            
	        Thread.sleep(2000);   
	           
	        System.out.println( Thread.currentThread().getName() +   
	        " Thread is woken after two second");   
	          
	        //create synchronize context from which we call Wait() method  
	        synchronized (obj)    
	        {   
	            obj.wait(2000);   
	  
	            System.out.println(obj + " Object is in waiting state ");   
	        }   
	    }   
	}  

