package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MphasisProjectphase32Application {

	public static void main(String[] args) {
		SpringApplication.run(MphasisProjectphase32Application.class, args);
	}

}
