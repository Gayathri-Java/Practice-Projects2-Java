package Project7;

import java.io.*;

public class Update {
    public static void main(String[] args) {
        // Specify the path of the file
        String filePath = "path/to/your/file.txt";

        try {
            // Open the file
            File file = new File(filePath);
            
            // Check if the file exists
            if (!file.exists()) {
                System.out.println("File does not exist.");
                System.exit(0);
            }
            
            // Read the content of the file
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder content = new StringBuilder();
            String line;
            
            while ((line = reader.readLine()) != null) {
                // Update the file content (e.g., modify specific lines)
                // For example, let's replace all occurrences of "old word" with "new word"
                line = line.replaceAll("old word", "new word");
                content.append(line).append("\n");
            }
            
            reader.close();
            
            // Write the updated content back to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(content.toString());
            writer.close();
            
            System.out.println("File updated successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}