package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.internal.MouseAction.Button;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App2 {
     public static void main(String[] args) throws InterruptedException  {
	
    	 WebDriverManager.chromedriver().setup();
         //creating an object to the object
         WebDriver wd=new ChromeDriver();
         //maximize the browser
         wd.manage().window().maximize();
         wd.get("https://www.hyrtutorials.com/p/basic-controls.html");
         Thread.sleep(3000);
         wd.findElement(By.id("femalerb")).click();
         Thread.sleep(3000);
         wd.findElement(By.id("englishchbx")).click();
         Thread.sleep(3000);
         WebElement hindiChk=wd.findElement(By.id("hindichbx"));
         hindiChk.click();
         Thread.sleep(3000);
         if(hindiChk.isSelected())
        	 hindiChk.click();
         Thread.sleep(3000);
         wd.findElement(By.id("registerbtn")).click();
        System.out.println (wd.findElement(By.id("msg")).getText());
        Thread.sleep(3000);
        wd.findElement(By.linkText("click here to navigate to home page")).click();
            
    }
}
