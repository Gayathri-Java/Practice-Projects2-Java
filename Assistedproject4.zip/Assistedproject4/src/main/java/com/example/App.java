package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.internal.MouseAction.Button;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App
{
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
        //creating an object to the object
        WebDriver wd=new ChromeDriver();
        //maximize the browser
        wd.manage().window().maximize();
        wd.get("https://github.com/login");
        Thread.sleep(3000);
        WebElement usernameTxt=wd.findElement(By.id("login_field"));
        if(usernameTxt.isDisplayed()) {
        	if(usernameTxt.isEnabled()) {
        		usernameTxt.sendKeys("tutorials");
        		String enteredText=usernameTxt.getAttribute("value");
        		 Thread.sleep(3000);
        		usernameTxt.clear();
        	}
        	else {
            	System.err.println("username textbox is not enabled");

        	}
        }
        else {
        	System.err.println("username textbox is not displayed");
        }
	}
}